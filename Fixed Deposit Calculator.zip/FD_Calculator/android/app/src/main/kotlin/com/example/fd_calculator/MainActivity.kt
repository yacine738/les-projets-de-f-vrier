package com.example.fd_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

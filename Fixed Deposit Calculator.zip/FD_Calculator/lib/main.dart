import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  GoogleFonts.config.allowRuntimeFetching = true;
  runApp(MaterialApp(
    home: HomePage(),
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      textTheme: GoogleFonts.robotoMonoTextTheme(
        ThemeData.light().textTheme,
      ),
    ),
  ));
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _controller1 = TextEditingController();
  final _controller2 = TextEditingController();
  final _controller3 = TextEditingController();
  double? interest;
  double? total;

  void calculation() {
    try {
      final principal = double.parse(_controller1.text);
      final rate = double.parse(_controller2.text);
      final months = double.parse(_controller3.text);

      final monthlyRate = rate / 100 / 12;
      final calInterest = principal * monthlyRate * months;

      setState(() {
        interest = calInterest;
        total = principal + calInterest;
      });
    } catch (e) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Invalid Input'),
          content: Text('Please enter valid numbers in all fields'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.menu, size: 30, color: Colors.white),
          onPressed: () {},
        ),
        toolbarHeight: 60,
        backgroundColor: Colors.blue,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.info, size: 30, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: body(),
    );
  }

  Widget body() {
    return Container(
      color: Colors.grey[100],
      child: Column(
        children: [
          Container(
            height: 170,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(100),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Fixed Deposit",
                      style: GoogleFonts.robotoMono(
                          fontSize: 35, color: Colors.white)),
                  Text("Calculator",
                      style: GoogleFonts.robotoMono(
                          fontSize: 35, color: Colors.white)),
                ],
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(30, 20, 30, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  inputForm(
                    title: "Deposit Amount : ",
                    controller: _controller1,
                    hintText: "e.g. 20000",
                  ),
                  inputForm(
                    title: "Annual Interest Rate(%) : ",
                    controller: _controller2,
                    hintText: "e.g. 3",
                  ),
                  inputForm(
                    title: "Period (in months): ",
                    controller: _controller3,
                    hintText: "e.g. 3",
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: calculation,
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 60),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25)),
                      backgroundColor: Colors.blue,
                    ),
                    child: Text("Calculate",
                        style: GoogleFonts.robotoMono(
                            fontSize: 25, color: Colors.white)),
                  ),
                  if (interest != null) ...[
                    SizedBox(height: 30),
                    Center(
                        child: Text("Results",
                            style: GoogleFonts.robotoMono(
                                fontSize: 24, fontWeight: FontWeight.bold))),
                    SizedBox(height: 20),
                    resultItem("Interest Earned:", interest!),
                    resultItem("Total Amount:", total!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget inputForm({
    required String title,
    required TextEditingController controller,
    required String hintText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: GoogleFonts.robotoMono(fontSize: 18)),
        SizedBox(height: 8),
        Container(
          height: 60,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))
            ],
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(15),
              ),
              hintText: hintText,
              contentPadding: EdgeInsets.symmetric(horizontal: 20),
            ),
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  Widget resultItem(String label, double value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.robotoMono(fontSize: 18)),
          Text("Tnd ${value.toStringAsFixed(2)}",
              style: GoogleFonts.robotoMono(
                  fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

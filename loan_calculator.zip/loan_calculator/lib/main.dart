import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() => runApp(MaterialApp(
      home: HomePage(),
    ));

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  final TextEditingController _controller3 = TextEditingController();
  String selected = '5';
  double? totalInterest;
  double? monthlyInterest;
  double? monthlyInstallment;

  void loanCalculation() {
    final amount =
        double.parse(_controller1.text) - double.parse(_controller2.text);
    final tinterest =
        amount * (double.parse(_controller3.text) / 100) * int.parse(selected);
    final minterest = tinterest / (int.parse(selected) * 12);
    final minstall = (amount + tinterest) / (int.parse(selected) * 12);

    setState(() {
      totalInterest = tinterest;
      monthlyInstallment = minstall;
      monthlyInterest = minterest;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu, size: 30, color: Colors.black),
        toolbarHeight: 60,
        backgroundColor: Colors.yellow,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.info, size: 30, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 170,
              decoration: BoxDecoration(
                color: Colors.yellow,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Car Loan",
                        style: GoogleFonts.robotoMono(fontSize: 35)),
                    Text("Calculator",
                        style: GoogleFonts.robotoMono(fontSize: 35)),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _inputForm("Car Price", "e.g 900000", _controller1),
                  _inputForm("Down Payment", "e.g 9000", _controller2),
                  _inputForm("Interest Rate", "e.g 3.5", _controller3),
                  const SizedBox(height: 10),
                  Text("Loan Period (years)",
                      style: GoogleFonts.robotoMono(fontSize: 20)),
                  _buildYearButtons(),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (_validateInputs()) {
                        loanCalculation();
                        _showResultsBottomSheet();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.yellow,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Text("Calculate",
                        style: GoogleFonts.robotoMono(
                            fontSize: 20, color: Colors.black)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _inputForm(
      String title, String hintText, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: GoogleFonts.robotoMono(fontSize: 18)),
        const SizedBox(height: 5),
        Container(
          height: 60,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              hintText: hintText,
            ),
          ),
        ),
        const SizedBox(height: 15),
      ],
    );
  }

  Widget _buildYearButtons() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(
              5, (index) => _loanPeriodButton((index + 1).toString())),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(
              4, (index) => _loanPeriodButton((index + 6).toString())),
        ),
      ],
    );
  }

  Widget _loanPeriodButton(String year) {
    return GestureDetector(
      onTap: () => setState(() => selected = year),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        height: 40,
        width: 40,
        decoration: BoxDecoration(
          color: Colors.yellow,
          borderRadius: BorderRadius.circular(8),
          border:
              selected == year ? Border.all(color: Colors.red, width: 2) : null,
        ),
        child: Center(child: Text(year)),
      ),
    );
  }

  bool _validateInputs() {
    if (_controller1.text.isEmpty ||
        _controller2.text.isEmpty ||
        _controller3.text.isEmpty) {
      _showErrorDialog("Please fill all fields");
      return false;
    }
    return true;
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Error", style: GoogleFonts.robotoMono()),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  void _showResultsBottomSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        height: 300,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Results",
                style: GoogleFonts.robotoMono(
                    fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            _resultRow("Total Interest", totalInterest),
            _resultRow("Monthly Interest", monthlyInterest),
            _resultRow("Monthly Installment", monthlyInstallment),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text("Close",
                    style: GoogleFonts.robotoMono(color: Colors.black)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _resultRow(String title, double? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: GoogleFonts.robotoMono(fontSize: 18)),
          Text("TND ${value?.toStringAsFixed(2) ?? '0.00'}",
              style: GoogleFonts.robotoMono(fontSize: 18)),
        ],
      ),
    );
  }
}
